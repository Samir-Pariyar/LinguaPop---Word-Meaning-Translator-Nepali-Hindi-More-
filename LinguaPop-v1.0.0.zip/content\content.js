// content.js - LinguaPop Fast Content Script (White & Gradient, Word Highlight Marker)

(function () {
  'use strict';

  if (window.__LINGUAPOP_INITIALIZED__) return;
  window.__LINGUAPOP_INITIALIZED__ = true;

  let activeTargetLang = 'ne'; // Default to Nepali
  let lastSelectedText = '';
  let popupCard = null;
  let selectionMarker = null;
  let isPinned = false;
  let isDragging = false;

  const POPULAR_LANGUAGES = [
    { code: 'ne', name: 'Nepali' },
    { code: 'hi', name: 'Hindi' },
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'zh-CN', name: 'Chinese' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ar', name: 'Arabic' }
  ];

  const ICONS = {
    book: `<svg viewBox="0 0 24 24"><path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z"/></svg>`,
    volume: `<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>`,
    close: `<svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>`,
    pin: `<svg viewBox="0 0 24 24"><path d="M16 9V4l1 0V2H7v2l1 0v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/></svg>`,
    copy: `<svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>`,
    check: `<svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>`
  };

  // Create isolated Shadow DOM Host
  const hostEl = document.createElement('div');
  hostEl.id = 'linguapop-host';
  document.documentElement.appendChild(hostEl);
  const shadow = hostEl.attachShadow({ mode: 'open' });

  // Pure White & White-Gradient Inlined CSS
  const styleEl = document.createElement('style');
  shadow.appendChild(styleEl);

  styleEl.textContent = '/* content.css - Pure White & White-Gradient Theme (Zero Blue) */\n\n:host {\n  all: initial;\n  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Noto Sans Devanagari", sans-serif;\n  font-size: 14px;\n  line-height: 1.5;\n  color: #0f172a;\n  z-index: 2147483647;\n  position: absolute;\n  top: 0;\n  left: 0;\n  pointer-events: none;\n}\n\n* {\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n}\n\n/* Word Highlight Marker on Webpage (visible when popup is open/pinned) */\n.lp-selection-marker {\n  position: absolute;\n  pointer-events: none;\n  background: rgba(254, 240, 138, 0.55) !important;\n  border-bottom: 2.5px solid #d97706 !important;\n  border-radius: 2px;\n  z-index: 2147483646;\n  box-shadow: 0 0 0 1px rgba(217, 119, 6, 0.2);\n  animation: lpMarkerFade 0.15s ease-out;\n}\n\n@keyframes lpMarkerFade {\n  from { opacity: 0; }\n  to { opacity: 1; }\n}\n\n/* Floating Trigger Icon (White Gradient) */\n.lp-trigger-btn {\n  pointer-events: auto;\n  position: absolute;\n  width: 30px;\n  height: 30px;\n  border-radius: 50%;\n  background: linear-gradient(180deg, #ffffff 0%, #f1f5f9 100%);\n  color: #0f172a;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15), 0 1px 3px rgba(0, 0, 0, 0.1);\n  border: 1.5px solid #cbd5e1;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n  z-index: 2147483647;\n  user-select: none;\n  animation: lpPopIn 0.15s ease-out;\n}\n\n.lp-trigger-btn:hover {\n  transform: scale(1.12);\n  background: linear-gradient(180deg, #ffffff 0%, #e2e8f0 100%);\n  border-color: #94a3b8;\n}\n\n.lp-trigger-btn svg {\n  width: 15px;\n  height: 15px;\n  fill: currentColor;\n}\n\n/* Pure White Popup Modal Card */\n.lp-popup-card {\n  pointer-events: auto;\n  position: absolute;\n  width: 370px;\n  max-width: calc(100vw - 20px);\n  max-height: 420px;\n  background: #ffffff !important;\n  color: #0f172a !important;\n  border-radius: 12px !important;\n  box-shadow: 0 12px 36px rgba(0, 0, 0, 0.16), 0 2px 8px rgba(0, 0, 0, 0.08) !important;\n  border: 1px solid #e2e8f0 !important;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  animation: lpFadeIn 0.15s ease-out;\n  z-index: 2147483647;\n}\n\n/* White Gradient Header */\n.lp-header {\n  padding: 11px 14px;\n  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%) !important;\n  border-bottom: 1px solid #e2e8f0 !important;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  cursor: grab;\n  user-select: none;\n  flex-shrink: 0;\n}\n\n.lp-header:active {\n  cursor: grabbing;\n}\n\n.lp-header-left {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  min-width: 0;\n  flex: 1;\n}\n\n.lp-logo-badge {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 6px;\n  background: linear-gradient(180deg, #ffffff 0%, #f1f5f9 100%);\n  border: 1px solid #cbd5e1;\n  color: #0f172a;\n  flex-shrink: 0;\n}\n\n.lp-logo-badge svg {\n  width: 13px;\n  height: 13px;\n  fill: currentColor;\n}\n\n.lp-query-word {\n  font-weight: 700;\n  font-size: 16px;\n  color: #0f172a !important;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 170px;\n}\n\n.lp-phonetic {\n  font-size: 13px;\n  color: #64748b !important;\n  font-style: italic;\n  font-weight: 400;\n}\n\n.lp-header-actions {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  flex-shrink: 0;\n}\n\n.lp-icon-btn {\n  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);\n  border: 1px solid #e2e8f0;\n  cursor: pointer;\n  padding: 5px;\n  border-radius: 6px;\n  color: #475569;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  transition: all 0.15s ease;\n}\n\n.lp-icon-btn:hover {\n  background: #f1f5f9;\n  border-color: #cbd5e1;\n  color: #0f172a;\n}\n\n.lp-icon-btn.speaking {\n  background: #0f172a;\n  color: #ffffff;\n  border-color: #0f172a;\n  animation: lpPulse 1s infinite alternate;\n}\n\n.lp-icon-btn.active {\n  background: #0f172a;\n  color: #ffffff;\n  border-color: #0f172a;\n}\n\n.lp-icon-btn svg {\n  width: 14px;\n  height: 14px;\n  fill: currentColor;\n}\n\n/* White Language Switcher Bar */\n.lp-lang-bar {\n  display: flex;\n  align-items: center;\n  padding: 8px 14px;\n  background: #ffffff !important;\n  gap: 6px;\n  border-bottom: 1px solid #f1f5f9 !important;\n  overflow-x: auto;\n  scrollbar-width: none;\n  flex-shrink: 0;\n}\n\n.lp-lang-bar::-webkit-scrollbar {\n  display: none;\n}\n\n.lp-lang-btn {\n  border: 1px solid #e2e8f0;\n  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);\n  padding: 4px 12px;\n  border-radius: 6px;\n  font-size: 12px;\n  font-weight: 600;\n  color: #475569;\n  cursor: pointer;\n  transition: all 0.15s ease;\n  white-space: nowrap;\n}\n\n.lp-lang-btn:hover {\n  background: #f1f5f9;\n  border-color: #cbd5e1;\n  color: #0f172a;\n}\n\n.lp-lang-btn.active {\n  background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%) !important;\n  border-color: #0f172a !important;\n  color: #ffffff !important;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);\n}\n\n.lp-lang-select {\n  margin-left: auto;\n  border: 1px solid #e2e8f0;\n  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);\n  color: #334155;\n  border-radius: 6px;\n  font-size: 11px;\n  padding: 3px 6px;\n  cursor: pointer;\n  outline: none;\n}\n\n/* Scrollable Content Body */\n.lp-body {\n  padding: 12px 14px;\n  overflow-y: auto;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  background: #ffffff !important;\n  flex: 1;\n}\n\n/* Minimal Sleek Scrollbar */\n.lp-body::-webkit-scrollbar {\n  width: 5px;\n}\n.lp-body::-webkit-scrollbar-track {\n  background: #ffffff;\n}\n.lp-body::-webkit-scrollbar-thumb {\n  background: #cbd5e1;\n  border-radius: 3px;\n}\n.lp-body::-webkit-scrollbar-thumb:hover {\n  background: #94a3b8;\n}\n\n/* White Gradient Section Cards */\n.lp-section-card {\n  background: linear-gradient(180deg, #ffffff 0%, #fafafa 100%) !important;\n  border: 1px solid #e2e8f0 !important;\n  border-radius: 8px;\n  padding: 10px 12px;\n}\n\n.lp-section-title {\n  font-size: 11px;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n  font-weight: 700;\n  color: #64748b;\n  margin-bottom: 6px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.lp-translation-text {\n  font-size: 22px;\n  font-weight: 700;\n  color: #0f172a !important;\n  line-height: 1.35;\n  word-break: break-word;\n}\n\n.lp-translit {\n  font-size: 12px;\n  color: #64748b;\n  margin-top: 2px;\n  font-style: italic;\n}\n\n/* Target Dictionary Synonyms */\n.lp-alt-meanings {\n  margin-top: 8px;\n  border-top: 1px dashed #e2e8f0;\n  padding-top: 6px;\n  font-size: 12px;\n}\n\n.lp-alt-pos {\n  font-weight: 600;\n  color: #0f172a;\n  margin-right: 4px;\n}\n\n.lp-alt-words {\n  color: #334155;\n}\n\n/* English Definition Block */\n.lp-def-group {\n  margin-bottom: 8px;\n}\n\n.lp-pos-badge {\n  display: inline-block;\n  font-size: 10px;\n  font-weight: 700;\n  text-transform: uppercase;\n  color: #0f172a;\n  background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);\n  border: 1px solid #cbd5e1;\n  padding: 1px 7px;\n  border-radius: 4px;\n  margin-bottom: 4px;\n}\n\n.lp-def-item {\n  font-size: 13px;\n  color: #1e293b;\n  line-height: 1.45;\n  margin-bottom: 5px;\n  padding-left: 8px;\n  border-left: 2px solid #cbd5e1;\n}\n\n.lp-def-example {\n  display: block;\n  font-size: 12px;\n  color: #64748b;\n  font-style: italic;\n  margin-top: 2px;\n}\n\n/* Synonyms Pills */\n.lp-synonyms-container {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n  margin-top: 6px;\n}\n\n.lp-synonym-pill {\n  font-size: 11px;\n  background: linear-gradient(180deg, #ffffff 0%, #f1f5f9 100%);\n  border: 1px solid #e2e8f0;\n  color: #1e293b;\n  padding: 2px 8px;\n  border-radius: 12px;\n}\n\n/* Fast Loading State */\n.lp-loading-spinner {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  padding: 24px 0;\n  gap: 10px;\n  color: #475569;\n  font-size: 13px;\n}\n\n.lp-spinner {\n  width: 24px;\n  height: 24px;\n  border: 3px solid #e2e8f0;\n  border-top-color: #0f172a;\n  border-radius: 50%;\n  animation: lpSpin 0.6s linear infinite;\n}\n\n/* Pure White Footer */\n.lp-footer {\n  padding: 8px 14px;\n  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%) !important;\n  border-top: 1px solid #e2e8f0 !important;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-size: 11px;\n  color: #64748b;\n  flex-shrink: 0;\n}\n\n.lp-copy-btn {\n  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);\n  border: 1px solid #cbd5e1;\n  border-radius: 5px;\n  padding: 4px 10px;\n  font-size: 11px;\n  font-weight: 500;\n  color: #1e293b;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  transition: all 0.15s ease;\n}\n\n.lp-copy-btn:hover {\n  background: #f1f5f9;\n  border-color: #94a3b8;\n  color: #0f172a;\n}\n\n/* Error State */\n.lp-error-box {\n  padding: 16px;\n  text-align: center;\n  color: #b91c1c;\n  font-size: 13px;\n}\n\n.lp-retry-btn {\n  margin-top: 8px;\n  background: #0f172a;\n  color: #ffffff;\n  border: none;\n  padding: 6px 14px;\n  border-radius: 6px;\n  font-size: 12px;\n  font-weight: 600;\n  cursor: pointer;\n}\n\n/* Animations */\n@keyframes lpPopIn {\n  from { opacity: 0; transform: scale(0.6); }\n  to { opacity: 1; transform: scale(1); }\n}\n\n@keyframes lpFadeIn {\n  from { opacity: 0; transform: translateY(4px); }\n  to { opacity: 1; transform: translateY(0); }\n}\n\n@keyframes lpSpin {\n  to { transform: rotate(360deg); }\n}\n\n@keyframes lpPulse {\n  from { transform: scale(1); }\n  to { transform: scale(1.2); }\n}\n';

  const container = document.createElement('div');
  container.className = 'lp-root';
  shadow.appendChild(container);

  // Sync settings (Always ensure Nepali is default)
  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ action: 'getSettings' }, (res) => {
      if (res && res.settings && res.settings.primaryLang && res.settings.primaryLang !== 'en') {
        activeTargetLang = res.settings.primaryLang;
      } else {
        activeTargetLang = 'ne';
      }
    });
  }

  // Event Listeners
  document.addEventListener('mouseup', handleMouseUp);
  document.addEventListener('mousedown', handleMouseDown);
  document.addEventListener('keydown', handleKeyDown);

  /**
   * STRICT CHECK:
   * Only trigger when the Alt key is pressed while selecting!
   * If Alt is NOT pressed, do nothing (regular select & copy text is completely unaffected).
   */
  function handleMouseUp(e) {
    if (e.composedPath && e.composedPath().includes(hostEl)) return;

    // STRICT: Alt key MUST be held down!
    if (!e.altKey) {
      return; // Do nothing!
    }

    setTimeout(() => {
      const selection = window.getSelection();
      const text = selection ? selection.toString().trim() : '';

      if (!text || text.length === 0 || text.length > 350) return;

      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) return;

      lastSelectedText = text;
      openPopup(text, rect);
    }, 10);
  }

  /**
   * Fast Alt Press:
   * If user selects text first and then presses Alt, open popup right there!
   */
  function handleKeyDown(e) {
    if (e.key === 'Escape' && popupCard) {
      removePopup();
      return;
    }

    if (e.key === 'Alt') {
      const selection = window.getSelection();
      const text = selection ? selection.toString().trim() : '';
      if (text && text.length > 0 && text.length <= 350 && !popupCard) {
        try {
          const range = selection.getRangeAt(0);
          const rect = range.getBoundingClientRect();
          if (rect.width > 0 || rect.height > 0) {
            e.preventDefault();
            lastSelectedText = text;
            openPopup(text, rect);
          }
        } catch (err) {}
      }
    }
  }

  function handleMouseDown(e) {
    if (e.composedPath && e.composedPath().includes(hostEl)) return;
    if (!isPinned) {
      removePopup();
    }
  }

  function removePopup() {
    if (popupCard) {
      popupCard.remove();
      popupCard = null;
      isPinned = false;
    }
    removeSelectionMarker();
  }

  /**
   * Highlight marker on webpage:
   * Keeps the selected word visibly highlighted while popup is open or pinned!
   */
  function showSelectionMarker(rect) {
    removeSelectionMarker();
    selectionMarker = document.createElement('div');
    selectionMarker.className = 'lp-selection-marker';
    const scrollX = window.scrollX || window.pageXOffset || 0;
    const scrollY = window.scrollY || window.pageYOffset || 0;
    selectionMarker.style.left = `${rect.left + scrollX - 2}px`;
    selectionMarker.style.top = `${rect.top + scrollY - 1}px`;
    selectionMarker.style.width = `${rect.width + 4}px`;
    selectionMarker.style.height = `${rect.height + 2}px`;
    container.appendChild(selectionMarker);
  }

  function removeSelectionMarker() {
    if (selectionMarker) {
      selectionMarker.remove();
      selectionMarker = null;
    }
  }

  /**
   * Open Pure White Popup:
   * Positioned so it is NEVER cut off by viewport or taskbar!
   */
  function openPopup(text, rect) {
    removePopup();

    // Show visual highlight on the referenced word
    showSelectionMarker(rect);

    popupCard = document.createElement('div');
    popupCard.className = 'lp-popup-card';

    const cardWidth = 370;
    const cardMaxHeight = 420;
    const scrollX = window.scrollX || window.pageXOffset || 0;
    const scrollY = window.scrollY || window.pageYOffset || 0;
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

    // Available card height guaranteed to fit on screen
    const availableHeight = Math.min(cardMaxHeight, viewportHeight - 30);
    popupCard.style.maxHeight = `${availableHeight}px`;

    // Smart vertical positioning:
    let top;
    // Check if it fits completely below the selection:
    if (rect.bottom + 8 + availableHeight <= viewportHeight) {
      top = scrollY + rect.bottom + 8;
    }
    // Check if it fits completely above the selection:
    else if (rect.top - 8 - availableHeight >= 0) {
      top = scrollY + rect.top - 8 - availableHeight;
    }
    // If tight space, place on the side with more room and clamp to screen:
    else {
      const spaceAbove = rect.top;
      const spaceBelow = viewportHeight - rect.bottom;
      if (spaceAbove >= spaceBelow) {
        top = scrollY + Math.max(12, rect.top - 8 - availableHeight);
      } else {
        top = scrollY + Math.max(12, viewportHeight - availableHeight - 12);
      }
    }

    // Horizontal positioning: center on selection, clamp inside viewport
    let left = scrollX + rect.left + rect.width / 2 - cardWidth / 2;
    if (left < scrollX + 12) left = scrollX + 12;
    if (left + cardWidth > scrollX + viewportWidth - 12) {
      left = scrollX + viewportWidth - cardWidth - 12;
    }

    popupCard.style.top = `${top}px`;
    popupCard.style.left = `${left}px`;
    popupCard.style.transform = 'none';

    renderSkeleton(text);
    container.appendChild(popupCard);
    setupDraggable(popupCard);

    // Fast word lookup (ensure default target is Nepali)
    const target = (activeTargetLang && activeTargetLang !== 'en') ? activeTargetLang : 'ne';
    fetchWordMeaning(text, target);
  }

  function renderSkeleton(text) {
    popupCard.innerHTML = `
      <div class="lp-header">
        <div class="lp-header-left">
          <span class="lp-logo-badge">${ICONS.book}</span>
          <span class="lp-query-word" title="${escapeHtml(text)}">${escapeHtml(text)}</span>
        </div>
        <div class="lp-header-actions">
          <button class="lp-icon-btn lp-close-btn" title="Close (Esc)">${ICONS.close}</button>
        </div>
      </div>
      <div class="lp-body">
        <div class="lp-loading-spinner">
          <div class="lp-spinner"></div>
          <span>Translating to Nepali...</span>
        </div>
      </div>
    `;

    popupCard.querySelector('.lp-close-btn').addEventListener('click', removePopup);
  }

  /**
   * Fast lookup: Tries direct fetch first (~300-500ms).
   * If blocked by page CSP, seamlessly falls back to background service worker.
   */
  async function fetchWordMeaning(text, targetLang) {
    try {
      const data = await executeDirectLookup(text, targetLang);
      if (popupCard) renderContent(data);
    } catch (directErr) {
      // Fallback to background service worker
      if (chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage(
          { action: 'lookup', text, targetLang },
          (res) => {
            if (!popupCard) return;
            if (res && res.success && res.data) {
              renderContent(res.data);
            } else {
              renderError(res ? res.error : 'Unable to connect to translation service.');
            }
          }
        );
      } else {
        renderError('Lookup failed. Please reload page.');
      }
    }
  }

  async function executeDirectLookup(text, targetLang) {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(targetLang)}&dt=t&dt=bd&dt=rm&dt=md&dt=ss&dt=ex&q=${encodeURIComponent(text)}`;
    
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);

    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();

    // 1. Translated text
    let translation = '';
    if (Array.isArray(data[0])) {
      translation = data[0].filter(i => i && i[0]).map(i => i[0]).join('');
    }

    // 2. Transliteration
    let transliteration = null;
    if (Array.isArray(data[0])) {
      for (const item of data[0]) {
        if (item && item.length > 2) {
          if (typeof item[3] === 'string' && item[3]) { transliteration = item[3]; break; }
          if (typeof item[2] === 'string' && item[2]) { transliteration = item[2]; break; }
        }
      }
    }

    const detectedSourceLang = data[2] || 'auto';

    // 3. Target Dictionary Meanings
    let targetDictionary = null;
    if (Array.isArray(data[1])) {
      targetDictionary = data[1].map(entry => ({
        partOfSpeech: entry[0] || 'meaning',
        words: Array.isArray(entry[1]) ? entry[1] : []
      }));
    }

    // 4. English Definitions
    let englishDefinition = null;
    if (Array.isArray(data[12]) && data[12].length > 0) {
      const groups = data[12].map(group => {
        const pos = group[0] || 'general';
        const defs = [];
        if (Array.isArray(group[1])) {
          for (const d of group[1]) {
            if (Array.isArray(d) && d[0]) {
              defs.push({ definition: d[0], example: d[2] || null });
            }
          }
        }
        return { partOfSpeech: pos, definitions: defs };
      });
      if (groups.some(g => g.definitions.length > 0)) {
        englishDefinition = { word: text, groups };
      }
    }

    // 5. Synonyms
    let synonyms = [];
    if (Array.isArray(data[11])) {
      for (const group of data[11]) {
        const synList = [];
        if (Array.isArray(group[1])) {
          for (const item of group[1]) {
            if (Array.isArray(item) && Array.isArray(item[0])) {
              synList.push(...item[0]);
            }
          }
        }
        if (synList.length > 0) {
          synonyms.push({ partOfSpeech: group[0], words: synList.slice(0, 8) });
        }
      }
    }

    // 6. Examples
    let examples = [];
    if (Array.isArray(data[13]) && Array.isArray(data[13][0])) {
      examples = data[13][0]
        .filter(ex => ex && ex[0])
        .map(ex => ex[0].replace(/<[^>]+>/g, ''))
        .slice(0, 2);
    }

    return {
      query: text,
      detectedSourceLang,
      targetLang,
      translation: translation || text,
      transliteration,
      targetDictionary,
      englishDefinition,
      synonyms,
      examples
    };
  }

  function renderContent(data) {
    if (!popupCard) return;

    const {
      query,
      detectedSourceLang,
      targetLang,
      translation,
      transliteration,
      targetDictionary,
      englishDefinition,
      synonyms,
      examples
    } = data;

    const phoneticLabel = transliteration ? `[${transliteration}]` : '';

    let html = `
      <div class="lp-header">
        <div class="lp-header-left">
          <span class="lp-logo-badge">${ICONS.book}</span>
          <span class="lp-query-word" title="${escapeHtml(query)}">${escapeHtml(query)}</span>
          ${phoneticLabel ? `<span class="lp-phonetic">${escapeHtml(phoneticLabel)}</span>` : ''}
        </div>
        <div class="lp-header-actions">
          <button class="lp-icon-btn lp-speak-btn" title="Pronounce word">${ICONS.volume}</button>
          <button class="lp-icon-btn lp-pin-btn ${isPinned ? 'active' : ''}" title="${isPinned ? 'Unpin' : 'Pin'}">${ICONS.pin}</button>
          <button class="lp-icon-btn lp-close-btn" title="Close (Esc)">${ICONS.close}</button>
        </div>
      </div>

      <!-- Clean Language Switcher Bar: Just Nepali, Hindi, English (No NP, IN, GB) -->
      <div class="lp-lang-bar">
        <button class="lp-lang-btn ${targetLang === 'ne' ? 'active' : ''}" data-lang="ne">Nepali</button>
        <button class="lp-lang-btn ${targetLang === 'hi' ? 'active' : ''}" data-lang="hi">Hindi</button>
        <button class="lp-lang-btn ${targetLang === 'en' ? 'active' : ''}" data-lang="en">English</button>
        
        <select class="lp-lang-select">
          <option value="" disabled selected>More...</option>
          ${POPULAR_LANGUAGES.filter(l => !['ne', 'hi', 'en'].includes(l.code)).map(l => `<option value="${l.code}" ${targetLang === l.code ? 'selected' : ''}>${l.name}</option>`).join('')}
        </select>
      </div>

      <div class="lp-body">
    `;

    // 1. Target Language Meaning Card (Show Nepali/Hindi meaning)
    if (targetLang !== 'en') {
      html += `
        <div class="lp-section-card">
          <div class="lp-section-title">
            <span>${getLangTitle(targetLang)} Meaning</span>
            <span style="font-size:10px; font-weight:normal; opacity:0.75;">From ${detectedSourceLang.toUpperCase()}</span>
          </div>
          <div class="lp-translation-text">${escapeHtml(translation || '—')}</div>
          ${transliteration ? `<div class="lp-translit">${escapeHtml(transliteration)}</div>` : ''}

          ${renderTargetDict(targetDictionary)}
        </div>
      `;
    }

    // 2. English Definition Card (Always show English definition when available)
    if (englishDefinition && englishDefinition.groups) {
      html += `
        <div class="lp-section-card">
          <div class="lp-section-title"><span>English Definition</span></div>
      `;
      englishDefinition.groups.slice(0, 2).forEach(g => {
        html += `
          <div class="lp-def-group">
            <span class="lp-pos-badge">${escapeHtml(g.partOfSpeech)}</span>
            ${g.definitions.slice(0, 2).map(d => `
              <div class="lp-def-item">
                <div>${escapeHtml(d.definition)}</div>
                ${d.example ? `<span class="lp-def-example">"${escapeHtml(d.example)}"</span>` : ''}
              </div>
            `).join('')}
          </div>
        `;
      });
      html += `</div>`;
    } else if (targetLang === 'en') {
      html += `
        <div class="lp-section-card">
          <div class="lp-section-title"><span>English Translation</span></div>
          <div class="lp-translation-text">${escapeHtml(translation || query)}</div>
        </div>
      `;
    }

    // 3. Synonyms
    if (synonyms && synonyms.length > 0) {
      const allSyns = synonyms.flatMap(s => s.words).slice(0, 7);
      if (allSyns.length > 0) {
        html += `
          <div class="lp-section-card" style="padding: 8px 12px;">
            <div class="lp-section-title"><span>Synonyms</span></div>
            <div class="lp-synonyms-container">
              ${allSyns.map(w => `<span class="lp-synonym-pill">${escapeHtml(w)}</span>`).join('')}
            </div>
          </div>
        `;
      }
    }

    // 4. Example Sentence
    if (examples && examples.length > 0) {
      html += `
        <div class="lp-section-card" style="padding: 8px 12px;">
          <div class="lp-section-title"><span>Usage Example</span></div>
          <div style="font-size: 12px; font-style: italic; color: #475569;">
            "${escapeHtml(examples[0])}"
          </div>
        </div>
      `;
    }

    html += `
      </div>
      <div class="lp-footer">
        <button class="lp-copy-btn" id="lp-copy-action">${ICONS.copy} <span>Copy Meaning</span></button>
        <span>Press <kbd style="background:#f1f5f9; padding:1px 4px; border-radius:3px; border:1px solid #cbd5e1; color:#0f172a;">Esc</kbd> to close</span>
      </div>
    `;

    popupCard.innerHTML = html;

    // Attach Event Handlers
    popupCard.querySelector('.lp-close-btn').addEventListener('click', removePopup);

    const speakBtn = popupCard.querySelector('.lp-speak-btn');
    speakBtn.addEventListener('click', () => {
      speakBtn.classList.add('speaking');
      playVoice(query, detectedSourceLang, () => speakBtn.classList.remove('speaking'));
    });

    const pinBtn = popupCard.querySelector('.lp-pin-btn');
    pinBtn.addEventListener('click', () => {
      isPinned = !isPinned;
      pinBtn.classList.toggle('active', isPinned);
    });

    // Language switcher buttons
    popupCard.querySelectorAll('.lp-lang-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const lang = e.currentTarget.getAttribute('data-lang');
        if (lang && lang !== activeTargetLang) {
          activeTargetLang = lang;
          renderSkeleton(query);
          fetchWordMeaning(query, activeTargetLang);
        }
      });
    });

    // Language dropdown
    const select = popupCard.querySelector('.lp-lang-select');
    if (select) {
      select.addEventListener('change', (e) => {
        if (e.target.value) {
          activeTargetLang = e.target.value;
          renderSkeleton(query);
          fetchWordMeaning(query, activeTargetLang);
        }
      });
    }

    // Copy Meaning
    const copyBtn = popupCard.querySelector('#lp-copy-action');
    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        const copyText = `${query} -> ${translation}`;
        navigator.clipboard.writeText(copyText).then(() => {
          copyBtn.innerHTML = `${ICONS.check} <span>Copied!</span>`;
          setTimeout(() => {
            if (copyBtn) copyBtn.innerHTML = `${ICONS.copy} <span>Copy Meaning</span>`;
          }, 1500);
        });
      });
    }
  }

  function renderTargetDict(dict) {
    if (!dict || !Array.isArray(dict) || dict.length === 0) return '';
    return `
      <div class="lp-alt-meanings">
        ${dict.slice(0, 2).map(entry => `
          <div style="margin-top: 3px;">
            <span class="lp-alt-pos">${escapeHtml(entry.partOfSpeech)}:</span>
            <span class="lp-alt-words">${escapeHtml(entry.words.slice(0, 4).join(', '))}</span>
          </div>
        `).join('')}
      </div>
    `;
  }

  function renderError(message) {
    if (!popupCard) return;
    popupCard.innerHTML = `
      <div class="lp-header">
        <div class="lp-header-left">
          <span class="lp-logo-badge">${ICONS.book}</span>
          <span class="lp-query-word">Meaning Lookup</span>
        </div>
        <div class="lp-header-actions">
          <button class="lp-icon-btn lp-close-btn">${ICONS.close}</button>
        </div>
      </div>
      <div class="lp-body">
        <div class="lp-error-box">
          <p>${escapeHtml(message)}</p>
          <button class="lp-retry-btn" id="lp-btn-retry">Try Again</button>
        </div>
      </div>
    `;
    popupCard.querySelector('.lp-close-btn').addEventListener('click', removePopup);
    popupCard.querySelector('#lp-btn-retry').addEventListener('click', () => {
      renderSkeleton(lastSelectedText);
      fetchWordMeaning(lastSelectedText, activeTargetLang);
    });
  }

  function playVoice(text, lang, onEnd) {
    if (!('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return;
    }
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = (lang && lang !== 'auto') ? lang : 'en-US';
    u.rate = 0.9;
    u.onend = () => { if (onEnd) onEnd(); };
    u.onerror = () => { if (onEnd) onEnd(); };
    window.speechSynthesis.speak(u);
  }

  function setupDraggable(card) {
    const header = card.querySelector('.lp-header');
    if (!header) return;

    let startX, startY, origLeft, origTop;

    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;

      const rect = card.getBoundingClientRect();
      origLeft = rect.left + window.scrollX;
      origTop = rect.top + window.scrollY;

      card.style.transform = 'none';
      card.style.left = `${origLeft}px`;
      card.style.top = `${origTop}px`;

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
      e.preventDefault();
    });

    function onMouseMove(e) {
      if (!isDragging) return;
      card.style.left = `${origLeft + (e.clientX - startX)}px`;
      card.style.top = `${origTop + (e.clientY - startY)}px`;
    }

    function onMouseUp() {
      isDragging = false;
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    }
  }

  function getLangTitle(code) {
    const found = POPULAR_LANGUAGES.find(l => l.code === code);
    return found ? found.name : code.toUpperCase();
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
})();
