// background.js - LinguaPop Service Worker

const DEFAULT_SETTINGS = {
  primaryLang: 'ne',      // Nepali
  secondaryLang: 'hi',    // Hindi
  triggerMode: 'alt',     // Hold Alt + Select
  theme: 'light',         // Pure White Theme
  fontSize: 'medium',
  autoPronounce: false,
  enabled: true
};

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const data = await chrome.storage.sync.get('settings');
    if (!data.settings) {
      await chrome.storage.sync.set({ settings: DEFAULT_SETTINGS });
    }
  } catch (err) {
    chrome.storage.local.get('settings', (localData) => {
      if (!localData.settings) {
        chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'lookup') {
    handleLookup(request)
      .then(response => sendResponse({ success: true, data: response }))
      .catch(error => sendResponse({ success: false, error: error.message || 'Lookup failed' }));
    return true; // Keep message channel open for async response
  }

  if (request.action === 'getSettings') {
    getSettings().then(settings => sendResponse({ success: true, settings }));
    return true;
  }

  if (request.action === 'saveSettings') {
    saveSettings(request.settings).then(() => sendResponse({ success: true }));
    return true;
  }
});

async function getSettings() {
  try {
    const data = await chrome.storage.sync.get('settings');
    return { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
  } catch (e) {
    const localData = await chrome.storage.local.get('settings');
    return { ...DEFAULT_SETTINGS, ...(localData.settings || {}) };
  }
}

async function saveSettings(newSettings) {
  try {
    await chrome.storage.sync.set({ settings: newSettings });
  } catch (e) {
    await chrome.storage.local.set({ settings: newSettings });
  }
}

/**
 * Fast, single-request lookup:
 * Retrieves translation, romanization, target synonyms, and English definitions in ONE network call.
 */
async function handleLookup({ text, targetLang = 'ne' }) {
  const query = text ? text.trim() : '';
  if (!query) throw new Error('Empty query');

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(targetLang)}&dt=t&dt=bd&dt=rm&dt=md&dt=ss&dt=ex&q=${encodeURIComponent(query)}`;
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Service returned HTTP ${response.status}`);
    }

    const data = await response.json();

    // 1. Translated text
    let translation = '';
    if (Array.isArray(data[0])) {
      translation = data[0]
        .filter(item => item && item[0])
        .map(item => item[0])
        .join('');
    }

    // 2. Transliteration / Romanization
    let transliteration = null;
    if (Array.isArray(data[0])) {
      for (const item of data[0]) {
        if (item && item.length > 2) {
          if (typeof item[3] === 'string' && item[3]) {
            transliteration = item[3];
            break;
          }
          if (typeof item[2] === 'string' && item[2]) {
            transliteration = item[2];
            break;
          }
        }
      }
    }

    // 3. Source Language
    const detectedSourceLang = data[2] || 'auto';

    // 4. Target Dictionary Meanings
    let targetDictionary = null;
    if (Array.isArray(data[1])) {
      targetDictionary = data[1].map(entry => ({
        partOfSpeech: entry[0] || 'meaning',
        words: Array.isArray(entry[1]) ? entry[1] : []
      }));
    }

    // 5. English Definitions
    let englishDefinition = null;
    if (Array.isArray(data[12]) && data[12].length > 0) {
      const groups = data[12].map(group => {
        const pos = group[0] || 'general';
        const defs = [];
        if (Array.isArray(group[1])) {
          for (const d of group[1]) {
            if (Array.isArray(d) && d[0]) {
              defs.push({
                definition: d[0],
                example: d[2] || null
              });
            }
          }
        }
        return { partOfSpeech: pos, definitions: defs };
      });

      if (groups.some(g => g.definitions.length > 0)) {
        englishDefinition = { word: query, groups };
      }
    }

    // 6. Synonyms
    let synonyms = [];
    if (Array.isArray(data[11])) {
      for (const group of data[11]) {
        const pos = group[0];
        const synList = [];
        if (Array.isArray(group[1])) {
          for (const item of group[1]) {
            if (Array.isArray(item) && Array.isArray(item[0])) {
              synList.push(...item[0]);
            }
          }
        }
        if (synList.length > 0) {
          synonyms.push({ partOfSpeech: pos, words: synList.slice(0, 8) });
        }
      }
    }

    // 7. Examples
    let examples = [];
    if (Array.isArray(data[13]) && Array.isArray(data[13][0])) {
      examples = data[13][0]
        .filter(ex => ex && ex[0])
        .map(ex => ex[0].replace(/<[^>]+>/g, ''))
        .slice(0, 2);
    }

    return {
      query,
      detectedSourceLang,
      targetLang,
      translation: translation || query,
      transliteration,
      targetDictionary,
      englishDefinition,
      synonyms,
      examples
    };
  } catch (err) {
    clearTimeout(timeoutId);
    throw err;
  }
}
