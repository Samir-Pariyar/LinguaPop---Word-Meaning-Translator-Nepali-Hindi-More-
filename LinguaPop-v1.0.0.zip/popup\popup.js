// popup.js - Toolbar Popup Script

document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  const btnSearch = document.getElementById('btn-search');
  const btnClear = document.getElementById('btn-clear');
  const btnOptions = document.getElementById('btn-options');
  const selectTargetLang = document.getElementById('select-target-lang');
  const selectTrigger = document.getElementById('select-trigger');
  const toggleEnabled = document.getElementById('toggle-enabled');
  const resultsArea = document.getElementById('results-area');

  let currentSettings = {};

  // Load existing settings
  chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
    if (response && response.success && response.settings) {
      currentSettings = response.settings;
      if (currentSettings.primaryLang) {
        selectTargetLang.value = currentSettings.primaryLang;
      }
      if (currentSettings.triggerMode) {
        selectTrigger.value = currentSettings.triggerMode;
      }
      toggleEnabled.checked = currentSettings.enabled !== false;
    }
  });

  // Open Options Page
  btnOptions.addEventListener('click', () => {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('options/options.html'));
    }
  });

  // Save changes on target language change
  selectTargetLang.addEventListener('change', () => {
    currentSettings.primaryLang = selectTargetLang.value;
    saveCurrentSettings();
    if (searchInput.value.trim()) {
      doLookup(searchInput.value.trim());
    }
  });

  // Save changes on trigger mode change
  selectTrigger.addEventListener('change', () => {
    currentSettings.triggerMode = selectTrigger.value;
    saveCurrentSettings();
  });

  // Save changes on master toggle
  toggleEnabled.addEventListener('change', () => {
    currentSettings.enabled = toggleEnabled.checked;
    saveCurrentSettings();
  });

  function saveCurrentSettings() {
    chrome.runtime.sendMessage({
      action: 'saveSettings',
      settings: currentSettings
    });
  }

  // Clear button logic
  searchInput.addEventListener('input', () => {
    btnClear.style.display = searchInput.value ? 'block' : 'none';
  });

  btnClear.addEventListener('click', () => {
    searchInput.value = '';
    btnClear.style.display = 'none';
    searchInput.focus();
    resultsArea.innerHTML = `
      <div class="welcome-hint">
        <p>💡 <strong>Tip:</strong> Simply select any word on any webpage to see its English definition and Nepali/Hindi translation instantly!</p>
      </div>
    `;
  });

  // Submit on Enter
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const text = searchInput.value.trim();
      if (text) doLookup(text);
    }
  });

  btnSearch.addEventListener('click', () => {
    const text = searchInput.value.trim();
    if (text) doLookup(text);
  });

  function doLookup(text) {
    resultsArea.innerHTML = `
      <div class="results-loading">
        <div class="spinner"></div>
        <span>Searching dictionary & translating...</span>
      </div>
    `;

    chrome.runtime.sendMessage(
      {
        action: 'lookup',
        text,
        targetLang: selectTargetLang.value,
        secondaryLang: currentSettings.secondaryLang || 'hi'
      },
      (res) => {
        if (res && res.success && res.data) {
          renderPopupResults(res.data);
        } else {
          resultsArea.innerHTML = `
            <div style="padding:16px; color:#ef4444; text-align:center;">
              ${res ? res.error : 'Lookup failed. Please check internet connection.'}
            </div>
          `;
        }
      }
    );
  }

  function renderPopupResults(data) {
    const {
      query,
      translation,
      transliteration,
      targetDictionary,
      secondaryTranslation,
      englishDefinition,
      detectedSourceLang
    } = data;

    const targetLangLabel = selectTargetLang.options[selectTargetLang.selectedIndex].text;

    let html = `
      <div class="result-header">
        <div>
          <span class="word-title">${escapeHtml(query)}</span>
          ${transliteration ? `<span class="phonetic-text">[${escapeHtml(transliteration)}]</span>` : ''}
        </div>
        <button id="btn-audio" class="audio-btn" title="Listen pronunciation">
          <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
        </button>
      </div>

      <!-- Target Translation Card -->
      <div class="result-card">
        <div class="card-label">${escapeHtml(targetLangLabel)} Meaning</div>
        <div class="translation-main">${escapeHtml(translation || '—')}</div>
        ${renderTargetDict(targetDictionary)}
      </div>
    `;

    // Secondary translation if available
    if (secondaryTranslation) {
      html += `
        <div class="result-card" style="padding: 8px 12px;">
          <div class="card-label">Alternative / Secondary Language</div>
          <div style="font-size: 14px; font-weight: 600; color: #334155;">${escapeHtml(secondaryTranslation)}</div>
        </div>
      `;
    }

    // English Definition Card
    if (englishDefinition && englishDefinition.groups) {
      html += `
        <div class="result-card">
          <div class="card-label">English Definition</div>
      `;

      englishDefinition.groups.slice(0, 2).forEach(g => {
        html += `
          <div style="margin-bottom: 6px;">
            <span class="pos-pill">${escapeHtml(g.partOfSpeech)}</span>
            ${g.definitions.slice(0, 2).map(d => `
              <div class="def-row">
                <div>${escapeHtml(d.definition)}</div>
                ${d.example ? `<div class="example-row">"${escapeHtml(d.example)}"</div>` : ''}
              </div>
            `).join('')}
          </div>
        `;
      });

      html += `</div>`;
    }

    resultsArea.innerHTML = html;

    // Audio button click
    const audioBtn = document.getElementById('btn-audio');
    if (audioBtn) {
      audioBtn.addEventListener('click', () => {
        playUtterance(query, detectedSourceLang);
      });
    }
  }

  function renderTargetDict(dict) {
    if (!dict || !Array.isArray(dict) || dict.length === 0) return '';
    return `
      <div style="margin-top: 6px; font-size: 11px; color: #475569; border-top: 1px dashed #cbd5e1; padding-top: 4px;">
        ${dict.slice(0, 2).map(e => `
          <div><strong>${escapeHtml(e.partOfSpeech)}:</strong> ${escapeHtml(e.words.slice(0, 4).join(', '))}</div>
        `).join('')}
      </div>
    `;
  }

  function playUtterance(text, lang) {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = (lang && lang !== 'auto') ? lang : 'en-US';
    u.rate = 0.9;
    window.speechSynthesis.speak(u);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
});
