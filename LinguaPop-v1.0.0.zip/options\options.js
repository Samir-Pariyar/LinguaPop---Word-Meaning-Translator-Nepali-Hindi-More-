// options.js - LinguaPop Options Page Script

document.addEventListener('DOMContentLoaded', () => {
  const optPrimaryLang = document.getElementById('opt-primary-lang');
  const optSecondaryLang = document.getElementById('opt-secondary-lang');
  const triggerRadios = document.getElementsByName('triggerMode');
  const optAutoPronounce = document.getElementById('opt-auto-pronounce');
  const optTheme = document.getElementById('opt-theme');
  const btnSaveHeader = document.getElementById('btn-save-header');
  const btnSaveBottom = document.getElementById('btn-save-bottom');
  const toastMsg = document.getElementById('toast-msg');

  // Load existing settings
  chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
    if (response && response.success && response.settings) {
      const s = response.settings;
      if (s.primaryLang) optPrimaryLang.value = s.primaryLang;
      if (s.secondaryLang) optSecondaryLang.value = s.secondaryLang;
      if (s.triggerMode) {
        for (const radio of triggerRadios) {
          if (radio.value === s.triggerMode) radio.checked = true;
        }
      }
      optAutoPronounce.checked = !!s.autoPronounce;
      if (s.theme) optTheme.value = s.theme;
    }
  });

  function getSelectedTriggerMode() {
    for (const radio of triggerRadios) {
      if (radio.checked) return radio.value;
    }
    return 'button';
  }

  function saveSettings() {
    const updated = {
      primaryLang: optPrimaryLang.value,
      secondaryLang: optSecondaryLang.value === 'none' ? null : optSecondaryLang.value,
      triggerMode: getSelectedTriggerMode(),
      autoPronounce: optAutoPronounce.checked,
      theme: optTheme.value,
      enabled: true
    };

    chrome.runtime.sendMessage(
      {
        action: 'saveSettings',
        settings: updated
      },
      (res) => {
        if (res && res.success) {
          showToast();
        }
      }
    );
  }

  function showToast() {
    toastMsg.style.display = 'inline-block';
    setTimeout(() => {
      toastMsg.style.display = 'none';
    }, 2500);
  }

  btnSaveHeader.addEventListener('click', saveSettings);
  btnSaveBottom.addEventListener('click', saveSettings);
});
